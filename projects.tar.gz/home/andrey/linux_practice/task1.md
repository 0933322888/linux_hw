TASK 1: LESS is the command that allows to search for text with many parameters. LESS accepts all params of MORE,
but also has its own. Unlike MORE command, LESS creates a buffer which allows to scroll text up and down. 
Manual doc for LESS is about 1300 lines.

TASK 2: -F, --classify
append indicator (one of */=>@|) to entries.


TASK 3: man 5 passwd>>output_file  

TASK 4: apropos systemd>>output_file

