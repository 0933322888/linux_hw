#!/bin/bash
clear
`date >> /tmp/temporary_sys`
`echo $PWD >> /tmp/temporary_sys`
exit 0

