   91  cat /etc/*-release >> explore_sys; history | tail -1 > task2.md
   96  ps aux >> explore_sys | history | tail -1 >> task2.md 
  107  ps -eo 'tty,pid,comm' | grep ^? >> explore_sys | history | tail -1 >> task2.md 
  116  df >> explore_sys | history | tail -1 >> task2.md 
  120  which vi >> explore_sys | history | tail -1 >> task2.md 
